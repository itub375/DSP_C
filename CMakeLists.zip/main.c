/*
 * Author: Jan Eberhardt
 * Integrated with 1:1 Python Deinterleaver Port
 */

#include "global.h"
#include "deinterleaver.h"

// Circular buffers
CircularBuffer rx_buffer;
CircularBuffer tx_buffer;

// Audio buffers
uint32_t in[BLOCK_SIZE];
uint32_t out[BLOCK_SIZE];
int16_t left_in[BLOCK_SIZE];
int16_t right_in[BLOCK_SIZE];
int16_t left_out[BLOCK_SIZE];
int16_t right_out[BLOCK_SIZE];

// Deinterleaver (1:1 aus Python)
RealtimeDeinterleaver deinterleaver;

// Temp buffers für float conversion
float audio_in_float[BLOCK_SIZE];
float audio_out_float[BLOCK_SIZE];

// System time counter für millis()
volatile uint32_t system_time_ms = 0;

// ============================================================================
// HELPER: millis() - System time in milliseconds
// ============================================================================
uint32_t millis(void) {
    // Diese Funktion muss die Zeit in ms zurückgeben
    // Option 1: Nutze einen Hardware Timer
    // Option 2: Zähle Audio-Blocks (hier verwendet)
    return system_time_ms;
}

void increment_time(void) {
    // Wird nach jedem Block aufgerufen
    // BLOCK_SIZE samples bei SAMPLE_RATE Hz = X ms
    uint32_t block_time_ms = (BLOCK_SIZE * 1000) / 32000;  // 32kHz sample rate
    system_time_ms += block_time_ms;
}

// ============================================================================
// MAIN
// ============================================================================
int main()
{
    // Initialize platform
    init_platform(115200, hz32000, line_in);
    
    debug_printf("%s, %s\n", __DATE__, __TIME__);
    IF_DEBUG(debug_printf("Audio Deinterleaver Starting...\n"));
    
    // Init test pin
    gpio_set(TEST_PIN, LOW);
    
    // Initialize circular buffers
    rx_buffer.init();
    tx_buffer.init();
    memset(in, 0, sizeof(in));
    memset(out, 0, sizeof(out));
    
    // =========================================
    // INITIALIZE DEINTERLEAVER (1:1 aus Python)
    // =========================================
    RealtimeConfig config = get_default_config();
    
    // Optional: Überschreibe Parameter wie in Python main()
    // config.OUTPUT_SIGNAL_INDEX = 1;  // Mittleres Signal
    // config.VERBOSE = false;
    // config.LATENCY_MS = 300.0f;  // Weniger Latenz
    
    RealtimeDeinterleaver_init(&deinterleaver, config);
    
    // Start I2S/DMA
    platform_start();
    
    debug_printf("\n[RUNNING] Audio-Stream aktiv\n");
    debug_printf("System läuft, warte auf Signal...\n\n");
    
    // =========================================
    // MAIN LOOP (entspricht Python audio_callback)
    // =========================================
    while(true)
    {
        // Step 1: Read block from input buffer
        while(!rx_buffer.read(in));
        
        // LED & Test Pin for timing
        gpio_set(LED_B, HIGH);  // LED off (processing)
        gpio_set(TEST_PIN, HIGH);
        
        // Step 2: Split into two channels
        convert_audio_sample_to_2ch(in, left_in, right_in);
        
        // =========================================
        // Step 3: DEINTERLEAVER PROCESSING
        // Entspricht Python: audio_callback(indata, outdata, frames, time_info, status)
        // =========================================
        
        // 3.1: Convert int16 to float (-1.0 to 1.0)
        // Python: input_audio = indata[:, 0]  # Mono
        for (uint32_t i = 0; i < BLOCK_SIZE; i++) {
            audio_in_float[i] = (float)left_in[i] / 32768.0f;
        }
        
        // 3.2: Process Block
        // Python: output_audio = self.process_block(input_audio)
        RealtimeDeinterleaver_process_block(&deinterleaver, 
                                           audio_in_float, 
                                           audio_out_float, 
                                           BLOCK_SIZE);
        
        // 3.3: Convert float back to int16
        // Python: outdata[:, 0] = output_audio
        for (uint32_t i = 0; i < BLOCK_SIZE; i++) {
            float sample = audio_out_float[i];
            
            // Clipping
            if (sample > 1.0f) sample = 1.0f;
            if (sample < -1.0f) sample = -1.0f;
            
            left_out[i] = (int16_t)(sample * 32767.0f);
        }
        
        // Copy to right channel (Stereo)
        // Python: outdata[:, 1] = output_audio
        memcpy(right_out, left_out, BLOCK_SIZE * sizeof(int16_t));
        
        // =========================================
        
        // Step 4: Merge channels back
        convert_2ch_to_audio_sample(left_out, right_out, out);
        
        // Step 5: Write to output buffer
        while(!tx_buffer.write(out));
        
        // Update system time for millis()
        increment_time();
        
        gpio_set(LED_B, LOW);    // LED on (idle)
        gpio_set(TEST_PIN, LOW);
    }
    
    // Cleanup (never reached, but good practice)
    RealtimeDeinterleaver_cleanup(&deinterleaver);
    
    fatal_error();
    return 0;
}

// ============================================================================
// DMA CALLBACKS (unchanged from original)
// ============================================================================
uint32_t* get_new_tx_buffer_ptr()
{
    uint32_t* temp = tx_buffer.get_read_ptr();
    if(temp == nullptr)
    {
        fatal_error();
    }
    return temp;
}

uint32_t* get_new_rx_buffer_ptr()
{
    uint32_t* temp = rx_buffer.get_write_ptr();
    if(temp == nullptr)
    {
        fatal_error();
    }
    return temp;
}