# FAILING TESTS

Those tests will have to be analyzed.

Cholesky 32x32 in fp16.
Fusion F64 failing 
