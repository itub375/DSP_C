#ifndef TEST_CONFIG_H
#define TEST_CONFIG_H

#define M55


#define POOL_ALLOCATOR
//#define ONLY_BENCHMARKS


#define MATRIX_TEST
#define Q7_DT
#define DYNAMIC_TEST
#define SUBTEST20

#endif

